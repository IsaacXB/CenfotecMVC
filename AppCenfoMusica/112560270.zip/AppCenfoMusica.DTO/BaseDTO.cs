﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppCenfoMusica.DTO
{
    public class BaseDTO
    {
        public int IdEntidad { get; set; }
        public string? Mensaje { get; set; }
    }
}
